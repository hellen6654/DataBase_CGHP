from django.views.generic import ListView, DetailView
from .models import Pizza
# Create your views here.
