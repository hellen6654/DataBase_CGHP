from django.apps import AppConfig


class PizzaConfig(AppConfig):
    name = 'pizza'
    verbose_name = '披薩管理'
    verbose_name_plural = '披薩管理'